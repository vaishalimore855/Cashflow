import './App.css';
import React from 'react';
import BalanceSheetTable from './components/Balance-Sheet/BalanceSheetTable';
import CashflowStatement1 from './components/CashFlowStatement/CashflowStatement1';
import AuditLogs from './components/Audit-Logs/AuditLogs';
import UploadedDocumentsB from './components/Upload-Documents/UploadedDocumentsB';
import TataSteels from './components/Upload-Documents/TataSteels';

function App() {
  return (
    <div >
     
      <BalanceSheetTable></BalanceSheetTable> 
    
      <CashflowStatement1></CashflowStatement1>
      <AuditLogs></AuditLogs>
      <UploadedDocumentsB></UploadedDocumentsB>
       {/* <TataSteels></TataSteels> */}
      
      <div>

      </div>
    </div>
  );
}

export default App;




