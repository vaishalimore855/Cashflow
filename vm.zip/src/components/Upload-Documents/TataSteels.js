import './UD.css';
import { Container } from '@mui/system'
import React from 'react'
import { Grid } from '@mui/material'
import { MenuItem } from '@mui/material'
import { Select } from '@mui/material'
import { InputLabel } from '@mui/material'
import { FormControl } from '@mui/material'
import { TextField } from "@mui/material"
import { Button } from '@mui/material'
import DriveFolderUploadOutlinedIcon from '@mui/icons-material/DriveFolderUploadOutlined';
import { Link } from "@mui/material"
const TataSteels = () => {
    return (
        <Container style={{ marginTop: 30, backgroundColor: "#f2f2f2", marginBottom: 10 }}>
            <h4 style={{ color: "gray" }}>Upload Documents</h4>
            <Grid container spacing={3}>
                <Grid item sx={{ mt: 2 }}>
                    <h6>Tata Steels</h6>
                </Grid>
                <Grid item xs>
                    <FormControl sx={{ mt: 1, minWidth: 230 }} size="small">
                        <InputLabel id="demo-select-small">Cash Flow Statement</InputLabel>
                        <Select>
                            <MenuItem value="">
                                <em>N</em>
                            </MenuItem>
                            <MenuItem value={10}>Ten</MenuItem>
                            <MenuItem value={20}>Twenty</MenuItem>
                            <MenuItem value={30}>Thirty</MenuItem>
                        </Select>
                    </FormControl>
                </Grid>
            </Grid>
            <Grid style={{ border: "1px solid black", height: 500 }} sx={{ mt: 3, p: 5 }}>
                <Grid container spacing={3} sx={{ mb: 5, justifyContent: 'space-around' }}>
                    <Grid item xs={2}>
                        <h6>Type  </h6>
                        <FormControl sx={{ mt: 1, minWidth: 120 }} size="small">
                           
                            <InputLabel id="demo-select-small" >Select</InputLabel>
                            <Select>
                                <MenuItem value="">
                                    <em>N</em>
                                </MenuItem>
                                <MenuItem value={10}>Ten</MenuItem>
                                <MenuItem value={20}>Twenty</MenuItem>
                                <MenuItem value={30}>Thirty</MenuItem>
                            </Select>
                        </FormControl>
                    </Grid>
                    <Grid item xs={2}>
                        <h6>Yearly/Quarterly/Monthly</h6>
                        <FormControl sx={{ mt: 1, minWidth: 120 }} size="small">
                            <InputLabel id="demo-select-small">Yearly</InputLabel>
                            <Select>
                                <MenuItem value="">
                                    <em>N</em>
                                </MenuItem>
                                <MenuItem value={10}>Ten</MenuItem>
                                <MenuItem value={20}>Twenty</MenuItem>
                                <MenuItem value={30}>Thirty</MenuItem>
                            </Select>
                        </FormControl>
                    </Grid>
                    <Grid item xs={2}>
                        <h6>Select duration</h6>
                        <FormControl sx={{ mt: 1, minWidth: 120 }} size="small">

                            <TextField sx={{ minWidth: 100 }} size="small" id="outlined-basic" label="22022-2023" variant="outlined" />
                        </FormControl>
                    </Grid>
                    <Grid item xs={2}>
                        <h6>Currency Rate</h6>
                        <FormControl sx={{ mt: 1, minWidth: 120 }} size="small">
                            <InputLabel id="demo-select-small">22022-2023</InputLabel>
                            <Select>
                                <MenuItem value="">
                                    <em>N</em>
                                </MenuItem>
                                <MenuItem value={10}>Ten</MenuItem>
                                <MenuItem value={20}>Twenty</MenuItem>
                                <MenuItem value={30}>Thirty</MenuItem>
                            </Select>
                        </FormControl>
                    </Grid>
                    <Grid item xs={2}>
                        <h6>Currency Rate</h6>
                        <FormControl sx={{ mt: 1, minWidth: 120 }} size="small">
                            <InputLabel id="demo-select-small">22022-2023</InputLabel>
                            <Select>
                                <MenuItem value="">
                                    <em>N</em>
                                </MenuItem>
                                <MenuItem value={10}>Ten</MenuItem>
                                <MenuItem value={20}>Twenty</MenuItem>
                                <MenuItem value={30}>Thirty</MenuItem>
                            </Select>
                        </FormControl>
                    </Grid>
                </Grid>
                <Grid style={{ border: "1px dotted gray" }} sx={{
                    height: 250, display: "flex",
                    justifyContent: "center", alignItems: "center"
                }}>
                    <Grid>
                        <DriveFolderUploadOutlinedIcon className='uploadIcon' style={{ color: "gray" }}></DriveFolderUploadOutlinedIcon>
                        <p>Drag and drop files here</p>
                        <p style={{ marginLeft: 60 }}>or</p>
                        <Link href="#" style={{ marginLeft: 40, color: "black", fontSize: 18, fontWeight: "bold" }}>Brouse</Link>
                    </Grid>
                </Grid>
                <Grid sx={{ display: 'flex', justifyContent: "flex-end", mt: 4 }}>
                    <Button className='uploadbtn' sx={{ bgcolor: "#303030", color: "white", width: 100 }}>Upload</Button>

                </Grid>
            </Grid>
        </Container>
    )
}

export default TataSteels
